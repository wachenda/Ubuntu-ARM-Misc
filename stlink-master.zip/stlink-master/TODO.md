# flash tool

- improve flash writing, still use word fast write... too slow

# documentation

- make README points to doc/tutorial

# testing

- compile and test a realtime kernel (e.g ChibiOS)
